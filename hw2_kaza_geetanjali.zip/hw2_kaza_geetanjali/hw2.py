#!/usr/bin/env python
# coding: utf-8

# # Homework 2 (Wednesday, Oct. 4, by midnight)
# 
# *****
# 
# **Name: Kaza Geetanjali** 
# 
# **Collaboration disclosure (if any): Nishat Jahan**
# 
# -------------
# 
# ## General Instructions
# 
# > Please make sure that you add your name and cite any help that you received on the assignment.
# 
# > Please also follow the specific instructions on style that were provided with the first homework.

# ## Conventions on Style for Function Definitions
# 
# - The name of a function should begin with lowercase letters, and should
# use underscores to separate meaningful parts (this is called **snake_case**).
# 
# - The formal parameters must have descriptive names.
# 
# - Each function should have a complete **docstring** in **Google** style with
# one line descriptions of the arguments and a description of the 
# **return value**.

# ## Developing Code
# 
# - All the functions to be implemented in this assignment have
#   been set up for you as **stubs**: you will need to 
#   complete the function bodies.
# 
# > As a novice programmer, the tendency is to try and write code for 
# **all** the functions **before** beginning to test the code: please avoid
# this at all costs! Robust code development is 
# *incremental*: you write code for a function, test it fully, and then move on to the next function. Doing this systematically will cut down
# substantially on the number of errors that you make.

# ## Testing
# 
# Some doctests have been provided with the stubs - if they work correctly without errors, that will give you some measure of confidence in your code! 
# 
# On the other hand, you could end up **writing code for the tests**, i.e., code that works for the given doctests but fails on 
# some test case that is not among the listed doctests. Starting with this assignment, we will start taking some baby steps towards integrating robust **testing** with code development. To do so, I will test your code with additional tests that you cannot see. I will explain this in more detail in class but it will need your code to be available as a Python module.
# 
# Here is the step-by-step process to follow when you are ready to submit:
# 
# - Using your command line (Unix) shell, navigate to the folder containing the notebook and create a **Python module** that corresponds to your Jupyter notebook:
# 
#     % cd <path-to-notebook-folder>
#     % jupyter nbconvert hw2.ipynb --to python
# 
# This should create `hw2.py` in the same folder: it contains all the code in your notebook but in text form (notebooks use XML that your browser renders). 
# 
# - Create a **zip file** containing your notebook and the Python module that has a copy of your notebook code.
# 
#     % zip -r hw2.zip hw2.ipynb hw2.py
# 
# - Submit the zip file.

# ## Problem 1
# 
# In the film, *The Martian*, that is based on a novel by Andy Weir, the
# astronaut Mark Watney (played by Matt Damon) is 
# left stranded on Mars. The only way to communicate with mission control back
# on earth is by using a programmable rotating camera that can go through a
# full 360 degree rotation.
# 
# 
# <img src="mars.png" width="300" /> 
# 
# We will use a small variation on the plan that Mark
# devises in the book/movie. The standard English ASCII alphabet is encoded on a
# computer using 1 byte (or 8 bits) per character. Since  
# every ASCII character can be encoded with two hexadecimal symbols (4 bits/symbol), Mark decides
# to place sixteen cards with the **hexadecimal** symbols `0` through `9` and
# `A` through `F` written on the cards on the circumference
# of a circle set up around the camera with a **22** degrees (approx) angle of view
# reserved for each card, e.g. as shown in the figure above, angle 0 degrees
# would correspond to the hexadecimal
# digit `0`, then the angle 22 degrees (going anti-clockwise) would correspond
# to the digit `1`, and so on until we get to angle 330 degrees for digit `F`.
# 
# Then, every word to be transmitted can be broken up into ASCII characters; 
# for each character, two camera pictures can be sent in sequence by Mark
# for the two hexadecimal symbols (on the cards) that make up that character.
# Mission control, in turn, can use the same technique to point the camera in
# the right directions corresponding to the response, thus two camera
# pointing operations per character of the message. By observing the camera, Mark can decipher or
# **decode** the ASCII message being sent by mission control!
# 
# Mark could use some help with writing the encoding and decoding functions.
# Fortunately for you, the built-in functions `hex()`, `ord()` and `chr()` are
# available. Consult the Python documentation to see what they do.
# *Hint:* You should use the two constants provided in the module. 
# 
# The key to developing the solution is to understand how to extract relevant 
# characters from strings, process them (e.g. compute numbers from them), and use
# **modulo** arithmetic to compute indexes in sequences. We will be using lists here to
# encode messages. 
# 
# **Note:** Do not modify the docstrings of the function stubs. They
# contain **doctests** that will pass silently **only if** the functions have been implemented correctly. I will also test your
# code separately on other inputs.
# 

# In[3]:


### Constants: Do not modify!!
HEX_CHARS = "0123456789ABCDEF"    
ANGLES = list(range(0,352,22))   # corresponding angles


# In[6]:


### Complete the function stub below: DO NOT MODIFY DOCSTRINGS!! ###

def mars_encode(ascii_msg) -> list[int]:
    """Each letter is encoded using its hexadecimal representation and the 
    corresponding angles obtained from ANGLES

    Args:
        ascii_msg (str): the message to be encoded
    Returns:
        list[int]: angles in degrees corresponding to the message

    >>> mars_encode('H')
    [88, 176]
    >>> mars_encode('o')
    [132, 330]
    >>> mars_encode('Hola!')
    [88, 176, 132, 330, 132, 264, 132, 22, 44, 22]
    """
    encoded_angles = []
    for char in ascii_msg:
        hex_value = hex(ord(char))[2:].upper()  # Convert character to hexadecimal and remove the '0x' prefix
        for digit in hex_value:
            index = HEX_CHARS.index(digit)
            angle = ANGLES[index]
            encoded_angles.append(angle)

    return encoded_angles


# In[9]:


mars_encode('H')


# In[12]:


def mars_decode(lst_angles) -> str:
    """Use the list of angles to decode the message

    Assumes that all angles are multiples of 22, are contained in the interval 
    [0, 330], and there are an even number of angles in the list.
    
    Args:
        lst_angles (list[int]): encoded message as a list of angles

    Returns:
        str: Decoded ASCII message

    >>> mars_decode([132, 176])
    'h'
    >>> mars_decode([88, 22, 132, 264, 132, 330, 132, 176, 132, 22])
    'Aloha'
    >>> mars_decode([88, 154, 132, 330, 44, 0, 110, 154, 132, 110, 154, 66, 154, 88, 44, 22])
    'Go West!'
    """
    decoded_message = ""
    hex_values = []

    for angle in lst_angles:
        index = ANGLES.index(angle)
        hex_digit = HEX_CHARS[index]
        hex_values.append(hex_digit)

    hex_string = "".join(hex_values)
    for i in range(0, len(hex_string), 2):
        hex_digit = hex_string[i:i + 2]
        char = chr(int(hex_digit, 16))
        decoded_message += char

    return decoded_message


# In[14]:


mars_decode([88, 154, 132, 330, 44, 0, 110, 154, 132, 110, 154, 66, 154, 88, 44, 22])


# ## Problem 2
# 
# The Unix utility `cal` prints a calendar - more accurately, it can print
# the calendar for a specific month or for a whole year. For instance:
# ```bash
# % cal 9 2020
# ```
# prints
# ```
#    September 2020     
# Su Mo Tu We Th Fr Sa  
#        1  2  3  4  5  
#  6  7  8  9 10 11 12  
# 13 14 15 16 17 18 19  
# 20 21 22 23 24 25 26  
# 27 28 29 30           
# ```
# In this problem, we will design a function that mimics the behavior above
# in a limited sense: it takes two arguments, a calendar month
# (an integer value between 1 and 12 inclusive) and a year (assumed
# to be in the 21st century or later, i.e. 2000 onwards), and returns 
# a **formatted string** whose printed representation will be **exactly**
# what you would get from the `cal` program for *that* month in *that* year. 
# 
# To make your task a little easier, you have been provided with:
# 
# - several **constants**: the tuple of string literals for the days of the week; 
#   the tuple with the string names of the calendar months in an year, the tuple with 
#   the number of days in each of the twelve months (starting from January) of a 
#   **non-leap** year, and of course, the number of days in a week. 
# 
# - a function to determine **leap years** 
# 
# - a function to determine the total number of days in a given month in a given year (note
#   that this will only change the number of days in February for a leap year from 28 to 29).
#   
# - a constant **reference day**: New Year's Day, 2000, was a Saturday, and Saturday is 
#   idenfied by the index 6 in the tuple containing the days of the week. 
#   
# As part of the problem, you need to complete two functions:
# 
# - an auxiliary function, `day_on_first_of`, that takes a month and an year (>= 2020) 
#   as  arguments and calculates an index for the day of the week for the first of *that* 
#   month in *that* year. For example, September 1, 2020, was a Tuesday, hence the 
#   function call, `day_on_first_of (9, 2020)` should return 2, the index for 
#   Tuesday in the tuple containing the names of the days of the week. This auxiliary 
#   function will make it easier for you to format the month string. 
#   **Hint:** Use the reference day (see `NEW_YRS_DAY_2000` below) and the given functions `is_leap_year` and `num_days_in` to figure out 
#   the definition of `days_on_first_of`.
# 
# - the function, `my_cal` that takes two arguments again: a month and an year (>= 2020).
#   It **assembles** and returns the string that when printed, will look like the output from the Unix `cal` utility. Approach this 
#   systematically: observe that the output consists of a *header line* that is centered
#   within a width of 20 characters, followed by a fixed string containing the abbreviated 
#   days of the week starting from 'Su' (for Sunday), and then followed by the familar 
#   calendar that lists, in formatted fashion, the dates in the month week by week. Note 
#   the single space between suucessive days of the week and the dates. **Hint:** You will need to use a loop to construct the entire string.
#   
# For this problem, you are **not allowed** to use any
# other built-in **time**-related modules
# from the Python standard library like `calendar`, `datetime` or `time`. 
# 

# In[18]:


### Constants: do not modify!!

#For non-leap years ...
DAYS_IN_MONTHS = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

MONTHS = ('January', 'February', 'March', 'April', 'May', 'June',\
          'July', 'August', 'September', 'October', 'November',\
          'December')
DAYS = ('Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa')
N_WEEKDAYS = 7
NEW_YRS_DAY_2000 = 6   # January 1, 2000, was a Saturday


# In[19]:


### Do not modify
def is_leap_year(year) -> bool:
    """Checks if year is a leap year.
    
    To qualify the year must be a multiple of 4, but not a multiple of 100
    unless it is a multiple of 400

    Args:
        year (int >= 2000): the year being checked

    Returns:
        bool: True iff year is a leap year
    """
    return (year%4 == 0) and ((year%100 != 0) or (year%400 == 0))


# In[20]:


### Do not modify
def num_days_in(month, year) -> int:
    """Returns the number of days in the given month and year.

    Args:
        month (int): month number between 1 and 12 (both inclusive)
        year (int): year >= 2000
    """
    result = DAYS_IN_MONTHS[month-1]
    if is_leap_year(year) and (month == 2):
        result += 1
    return result


# In[21]:


### Complete the function body
### Include assert statements to check that the month and year are legal ###

def day_on_first_of(month, year) -> int: 
    """Returns the day on the 1st of the given month and year.
    
    Days are numbered from 0 (Sunday) through 6 (Saturday)

    Args:
        month (int): month number between 1 and 12 (both inclusive)
        year (int): year >= 2000
    Returns:
        int: value in `range(7)`
    
    >>> day_on_first_of(1, 2024)
    1
    >>> day_on_first_of(1, 3000)
    3
    """
    # Assert that the month is in the valid range (1 to 12)
    assert 1 <= month <= 12, "Month must be between 1 and 12 (inclusive)"

    # Assert that the year is valid (greater than or equal to 2000)
    assert year >= 2000, "Year must be greater than or equal to 2000"


    # Reference day: New Year's Day, 2000, was a Saturday (index 6)
    day_index = NEW_YRS_DAY_2000

    # Calculate the day of the week for the first day of the given year
    for y in range(2000, year):
        if is_leap_year(y):
            day_index += 2  # Leap year adds 2 days
        else:
            day_index += 1  # Non-leap year adds 1 day

    # Calculate the day of the week for the first day of the given month
    for m in range(1, month):
        day_index += num_days_in(m, year)

    return day_index % N_WEEKDAYS


# In[23]:


day_on_first_of(1, 3000)


# In[25]:


def my_cal(month, year) -> str:
    """Returns the printable calendar for the given month and year.
    
    Output identical to the output from the Unix `cal` utility    
    
    Args:
        month (int): month number between 1 and 12 (both inclusive)
        year (int): year >= 2020
    """
    # Get the day of the week for the first day of the month
    first_day_index = day_on_first_of(month, year)

    # Get the number of days in the month
    num_days = num_days_in(month, year)

    # Create the header line
    header = f"{MONTHS[month - 1]} {year}".center(20)

    # Create the days of the week string
    days_of_week_str = ' '.join(DAYS)

    # Initialize the calendar string with the header and days of the week
    cal_str = f"{header}\n{days_of_week_str}\n"

    # Initialize variables for tracking the current day of the week and day of the month
    current_day_index = first_day_index
    current_day = 1

    # Generate the calendar
    while current_day <= num_days:
        # Add spaces before the first day of the month
        if current_day == 1:
            cal_str += " " * (current_day_index * 3)

        # Add the day to the calendar
        cal_str += f"{current_day:2d} "

        # If it's the end of the week, start a new line
        if current_day_index == N_WEEKDAYS - 1:
            cal_str += '\n'

        # Move to the next day
        current_day += 1
        current_day_index = (current_day_index + 1) % N_WEEKDAYS

    return cal_str


# In[27]:


print(my_cal(4, 2026))

print(my_cal(1, 2024))
# The cell above is a Raw cell. If you convert it to a Code cell and evaluate it, you should get output that looks like this (assuming you have implemented my_cal correctly):

#         January 2024      
#     Su Mo Tu We Th Fr Sa  
#         1  2  3  4  5  6  
#      7  8  9 10 11 12 13  
#     14 15 16 17 18 19 20  
#     21 22 23 24 25 26 27  
#     28 29 30 31           
# 

# ## Problem 3
# 
# The Roman numerals **I**, **V**, **X**, **L**, **C**, **D** and **M** 
# respectively represent the decimal values 1, 5, 10, 50, 100, 500 and 1000. 
# Roman numerals can only be concatenated in specific ways to form a 
# *Roman number*, and in fact, we will only use the following rules to 
# construct such numbers whose  corresponding base-10 values range between 
# 1 and 3999 inclusive:
# 
# 1. The numerals V, L, and D are not repeated, e.g., the patterns 
# `VV`, `DDD` etc. are illegal anywhere in a Roman number.
# 
# 2. The other numerals I, X, C and M can only be repeated at most **three** 
# times, and each repeated block contributes a corresponding 
# **additive combination** of that numeral. For example, 
# `III` is 1 + 1 + 1 = 3, `XX` is 10 + 10 = 20 etc. 
# 
# 3. The numerals I, X, and C can be used as 
# *starting* numerals in the following **subtractive combinations**: 
#     - `IV` is 5 - 1 = 4; `IX` is 10 - 1 = 9; 
#     - `XL` is 50 - 10 = 40; `XC` = 100 - 10 = 90; 
#     - `CD` = 500 - 100 = 400; and `CM` is 1000 - 100 = 900.
# No other subtractive combinations are permissible.
# 
# 4. From left to right, the Roman numeral string can be "parsed" into blocks 
# made up of additive and subtractive combinations. The numeral that starts 
# each block must have a **strictly larger** numeric value than the value of 
# the numeral that starts the next block, i.e., `IIX`, `XXXCM`, `LVIIV` etc. 
# are illegal but `CCXCIV` (which is 200 + 90 + 4 = 294) is legal. 
# 
# For example, the legal Roman number `MMCCCXCIX` corresponds to
# 2399 = 2000 (the additive value of `MM`) + 300 (the additive value of `CCC`) 
# + 90 (the subtractive value of `XC`) + 9 (the subtractive value of `IX`).
# 
# Complete the two function stubs below. You are only allowed 
# to use string functions/methods and list functions (if necessary) 
# but **no dictionaries**. 
# 

# In[29]:


### Constants: Do not modify!

ROMAN = ('I', 'V', 'X', 'L', 'C', 'D', 'M')
VALUES = (1, 5, 10, 50, 100, 500, 1000)
SUB_START = ('I', 'X', 'C')
SUB_COMBOS = ('IV', 'IX', 'XL', 'XC', 'CD', 'CM')


# In[39]:


def is_legal_roman_numeral(numeral: str) -> bool:
    """Checks if Roman numeral is a syntactically legal numeral.
   
    Please add more doctests below!
   
    >>> is_legal_roman_numeral('DDD')
    False
    >>> is_legal_roman_numeral('CCXCIX')
    True
    """

    # Check for valid characters and subtractive combinations
    i = 0
    while i < len(numeral):
        # Check for valid characters
        if numeral[i] not in ROMAN:
            return False

        # Check for subtractive combinations
        if i < len(numeral) - 1 and numeral[i:i + 2] in SUB_COMBOS:
            i += 2  # Skip two characters for subtractive combinations
        else:
            i += 1

    # Check for repeating characters (I, X, C, M)
    for char in "IXCM":
        if numeral.count(char) > 3:
            return False

    # Check for repeating characters (V, L, D)
    for char in "VLD":
        if numeral.count(char) > 1:
            return False
    return True

def value_of(numeral: str) -> int:
    """Converts a Roman numeral to its base-10 value
   
    This functions assumes that `numeral` is a legal Roman numeral.
    Please add more doctests below.

    Args:
        numeral (str): Roman numeral
    Returns:
        int: base-10 value of input numeral
       
    >>> value_of('CCXCIV')
    294
    >>> value_of('MMXXIII')
    2023
    """
    # Initialize the result value
    result = 0

    # Initialize the previous value for comparison
    prev_value = 0

    # Iterate through the Roman numeral string in reverse order
    for char in reversed(numeral):
        # Find the corresponding value for the character
        char_value = VALUES[ROMAN.index(char)]

        # Check if we need to subtract the value
        if char in SUB_START and prev_value > char_value:
            result -= char_value
        else:
            result += char_value

        # Update the previous value for the next iteration
        prev_value = char_value

    return result


# In[36]:


is_legal_roman_numeral('CCXCIX')


# In[38]:


value_of('CCXCIV')


# ### Running the doctests
# 
# As mentioned above, you should not write down all the code before testing it! 
# Evaluate the cell below (after converting it from a Raw to a Code cell) if you wish to run the doctests at any stage.

# In[41]:


import doctest
doctest.testmod()


# In[ ]:




